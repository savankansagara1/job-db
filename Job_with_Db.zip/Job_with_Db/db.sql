CREATE DATABASE job_app;

USE job_app;

create Table basic_table(
    basic_id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    designation VARCHAR(50),
    address1 varchar(50),
    address2 VARCHAR(50),
    email VARCHAR(50),
    city VARCHAR(50),
    state1 VARCHAR(50),
    gender VARCHAR(50),
    rs varchar(10),
    dob DATE,
    phoneno VARCHAR(10),
    zipcode varchar(6)
);

DESC basic_table;

SHOW TABLES;

SELECT * FROM basic_table;

CREATE TABLE education_type (
    edu_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(50)
);

INSERT INTO
    education_type (type_name)
VALUES ('SSC'),
    ('HSC'),
    ('Bachelor'),
    ('Master');
SELECT * from education_type;
CREATE TABLE education_details (
    edu_detail_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    education_type_id INT,
    course_name VARCHAR(100),
    board_or_university VARCHAR(100),
    passing_year INT,
    percentage DECIMAL(5, 2),
    FOREIGN KEY (student_id) REFERENCES basic_table (basic_id),
    FOREIGN KEY (education_type_id) REFERENCES education_type (edu_id)
);

SELECT * from education_details

SELECT b.basic_id, b.first_name, b.last_name, t.type_name, e.course_name, e.board_or_university, e.passing_year, e.percentage
FROM
    basic_table b
    JOIN education_details e ON b.basic_id = e.student_id
    JOIN education_type t ON e.education_type_id = t.edu_id;

SELECT e.student_id, t.type_name, e.course_name, e.board_or_university, e.passing_year, e.percentage
FROM
    education_details e
    JOIN education_type t ON e.education_type_id = t.edu_id;

CREATE TABLE work_experience (
    work_id INT PRIMARY KEY AUTO_INCREMENT,
    basic_id INT,
    company_name VARCHAR(100),
    designation VARCHAR(100),
    from_date DATE,
    to_date DATE,
    FOREIGN KEY (basic_id) REFERENCES basic_table (basic_id)
);


CREATE TABLE languages (
    lang_id INT PRIMARY KEY AUTO_INCREMENT,
    language_name VARCHAR(50)
);

INSERT INTO languages (language_name) values ("english"),('Hindi'),
('Gujarati');

CREATE TABLE student_languages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    basic_id INT,
    lang_id INT,
    can_read BOOLEAN,
    can_write BOOLEAN,
    can_speak BOOLEAN,
    FOREIGN KEY (basic_id) REFERENCES basic_table (basic_id),
    FOREIGN KEY (lang_id) REFERENCES languages (lang_id)
);

CREATE TABLE technologies (
    tech_id INT PRIMARY KEY AUTO_INCREMENT,
    tech_name VARCHAR(50)
);

CREATE TABLE student_technologies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    basic_id INT,
    tech_id INT,
    level ENUM(
        'Beginner',
        'Intermediate',
        'Expert'
    ),
    FOREIGN KEY (basic_id) REFERENCES basic_table (basic_id),
    FOREIGN KEY (tech_id) REFERENCES technologies (tech_id)
);
CREATE TABLE reference_contacts (
    ref_id INT PRIMARY KEY AUTO_INCREMENT,
    basic_id INT,
    name VARCHAR(100),
    contact_number VARCHAR(15),
    relation VARCHAR(50),
    FOREIGN KEY (basic_id) REFERENCES basic_table (basic_id)
);

CREATE TABLE preferences (
    pref_id INT PRIMARY KEY AUTO_INCREMENT,
    basic_id INT,
    preferred_location VARCHAR(100),
    notice_period VARCHAR(50),
    department VARCHAR(100),
    expected_ctc DECIMAL(10, 2),
    FOREIGN KEY (basic_id) REFERENCES basic_table (basic_id)
);