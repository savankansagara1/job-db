const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Dev@1234",
  database: "job_application_system",
});
db.connect((err)=>{
  if(err) {
    console.log("database connection error")
  } else{
    console.log("DAtabase connection successful")
  }
})


module.exports = db 