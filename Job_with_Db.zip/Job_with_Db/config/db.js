const mysql = require("mysql2");

const dbconn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Dev@1234",
  database: "job_app",
});
dbconn.connect((err)=>{
  if(err) {
    console.log("database connection error")
  } else{
    console.log("DAtabase connection successful")
  }
})


module.exports = dbconn 