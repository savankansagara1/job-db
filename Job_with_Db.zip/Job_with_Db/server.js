const express = require('express');
const db = require("./config/db")
const app = express();
const port = process.env.PORT || 3000;

app.set("view engine","ejs")

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes

app.get("/get" ,(req,res)=>{
    console.log(req.query)
    res.redirect("/education")
});

app.get('/', (req, res) => {
res.render("basic_form")
});


app.get("/education",(req,res) => {
    res.render("education_form")
})

app.get("/languageknown" , (req,res)=> {
    res.render("languageKnown")
})

app.get("/referances" , (req,res) => {
    res.render("referances")
})

app.get("/preferances", (req,res)=>{
    res.render("preferances")
})

app.get("/workexp",(req,res)=>{
    res.render("workexp_form")
})
// Start server
app.listen(8080, () => {
  console.log(`http://localhost:8080`);
});