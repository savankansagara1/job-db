const express = require("express");
const dbconn = require("./config/db");
const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

// ================= BASIC =================
app.get("/", (req, res) => {
  res.render("basic_form");
});

app.post("/", (req, res) => {
  const {
    fname,
    lname,
    Designation,
    Address1,
    Address2,
    Email,
    city,
    state,
    gender,
    zipcode,
    relationshipstatus,
    phonenumber,
    db,
  } = req.body;

  const sql = `INSERT INTO basic_table
  (first_name,last_name,designation,address1,address2,email,city,state1,gender,zipcode,rs,phoneno,dob)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`;

  dbconn.query(
    sql,
    [
      fname,
      lname,
      Designation,
      Address1,
      Address2,
      Email,
      city,
      state,
      gender,
      zipcode,
      relationshipstatus,
      phonenumber,
      db,
    ],
    (err, result) => {
      if (err) return res.send("DB Error");
      res.redirect(`/education?student_id=${result.insertId}`);
    },
  );
});

// ================= EDUCATION =================
app.get("/education", (req, res) => {
  res.render("education_form", { studentId: req.query.student_id });
});

app.post("/education", (req, res) => {
  const {
    student_id,
    nameofboard,
    passingyear,
    percentage1,
    nameofboard1,
    passingyear1,
    percentage2,
    coursename1,
    University1,
    passingyear2,
    percentage3,
    coursename2,
    University2,
    passingyear3,
    percentage4,
  } = req.body;

  const sql = `INSERT INTO education_details (student_id, education_type_id, course_name, board_or_university, passing_year, percentage) VALUES ?`;

  const values = [
    [student_id, 1, null, nameofboard, passingyear, percentage1],
    [student_id, 2, null, nameofboard1, passingyear1, percentage2],
    [student_id, 3, coursename1, University1, passingyear2, percentage3],
    [student_id, 4, coursename2, University2, passingyear3, percentage4],
  ];

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/workexp?student_id=${student_id}`);
  });
});

// ================= WORK =================
app.get("/workexp", (req, res) => {
  res.render("workexp_form", { studentId: req.query.student_id });
});

app.post("/workexp", (req, res) => {
  const {
    studentId,
    company1,
    designation1,
    from1,
    to1,
    company2,
    designation2,
    from2,
    to2,
    company3,
    designation3,
    from3,
    to3,
  } = req.body;

  const sql = `INSERT INTO work_experience (basic_id, company_name, designation, from_date, to_date) VALUES ?`;

  const values = [
    [studentId, company1, designation1, from1, to1],
    [studentId, company2, designation2, from2, to2],
    [studentId, company3, designation3, from3, to3],
  ].filter((v) => v[1] && v[2]);

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/languageknown?student_id=${studentId}`);
  });
});

// ================= LANGUAGE =================
app.get("/languageknown", (req, res) => {
  res.render("languageKnown", { studentId: req.query.student_id });
});

app.post("/languageknown", (req, res) => {
  const {
    studentId,
    english,
    englishRead,
    englishWrite,
    englishSpeak,
    hindi,
    hindiRead,
    hindiWrite,
    hindiSpeak,
    gujarati,
    gujaratiRead,
    gujaratiWrite,
    gujaratiSpeak,
  } = req.body;

  const sql = `
    INSERT INTO student_languages
    (basic_id, lang_id, can_read, can_write, can_speak)
    VALUES ?
  `;

  let values = [];

  // English → lang_id = 1
  if (english) {
    values.push([
      studentId,
      1,
      englishRead ? 1 : 0,
      englishWrite ? 1 : 0,
      englishSpeak ? 1 : 0,
    ]);
  }

  // Hindi → lang_id = 2
  if (hindi) {
    values.push([
      studentId,
      2,
      hindiRead ? 1 : 0,
      hindiWrite ? 1 : 0,
      hindiSpeak ? 1 : 0,
    ]);
  }

  // Gujarati → lang_id = 3
  if (gujarati) {
    values.push([
      studentId,
      3,
      gujaratiRead ? 1 : 0,
      gujaratiWrite ? 1 : 0,
      gujaratiSpeak ? 1 : 0,
    ]);
  }

  // If nothing selected → skip insert
  if (values.length === 0) {
    return res.redirect(`/technologyknown?student_id=${studentId}`);
  }

  dbconn.query(sql, [values], (err, result) => {
    if (err) {
      console.log(err);
      return res.send("DB Error");
    }

    console.log("Language inserted");

    res.redirect(`/technologyknown?student_id=${studentId}`);
  });
});

// ================= TECHNOLOGY =================
app.get("/technologyknown", (req, res) => {
  res.render("technologyKnown", { studentId: req.query.student_id });
});

app.post("/technologyknown", (req, res) => {
  const { studentId } = req.body;
});

// ================= REFERENCES =================
app.get("/referances", (req, res) => {
  const studentId = req.query.student_id;

  res.render("referances", { studentId });
});

app.post("/referances", (req, res) => {
  const { studentId, name1, contact1, relation1, relation2, name2, contact2 } =
    req.body;
  console.log(req.body);

  const sql = `INSERT INTO reference_contacts (basic_id,name,contact_number,relation) values ?`;
  const values = [
    [studentId, name1, contact1, relation1],
    [studentId, name2, contact2, relation2],
  ];

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/preferances?student_id=${studentId}`);
  });
});

app.get("/preferances", (req, res) => {
  res.render("preferances", { studentId: req.query.student_id });
});

app.post("/preferances", (req, res) => {
  const {
    studentId,
    preferred_location,
    notice_period,
    department,
    expected_ctc,
  } = req.body;

const sql = `INSERT INTO preferences 
(basic_id, preferred_location, notice_period, department, expected_ctc) 
VALUES (?, ?, ?, ?, ?)`;

  const values = [
    studentId,
    preferred_location,
    notice_period,
    department,
    expected_ctc
  ];

  dbconn.query(sql, values, (err) => {
    if (err) {
      return res.send("Error in DB");
    } else {
      console.log("success");
      res.send(`
        <html><body style="font-family:Arial;text-align:center;padding:60px;">
          <h2 style="color:#27ae60;">&#10003; Application submitted successfully!</h2>
          <p style="margin:20px 0;">
            <a href="/" style="margin:0 10px;padding:10px 22px;background:#4a90e2;color:#fff;border-radius:5px;text-decoration:none;">+ New Application</a>
            <a href="/applicants" style="margin:0 10px;padding:10px 22px;background:#27ae60;color:#fff;border-radius:5px;text-decoration:none;">&#128100; View All Applicants</a>
          </p>
        </body></html>
      `);
    }
  });
});

// ================= VIEW ALL APPLICANTS (PAGINATED) =================
app.get("/applicants", (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = 10;
  const offset = (page - 1) * limit;

  dbconn.query("SELECT COUNT(*) AS total FROM basic_table", (err, countResult) => {
    if (err) return res.send("DB Error");
    const totalCount = countResult[0].total;
    const totalPages = Math.max(1, Math.ceil(totalCount / limit));

    dbconn.query(
      "SELECT * FROM basic_table ORDER BY basic_id DESC LIMIT ? OFFSET ?",
      [limit, offset],
      (err2, applicants) => {
        if (err2) return res.send("DB Error");
        res.render("applicants", { applicants, page, totalPages, totalCount });
      }
    );
  });
});

// ================= EDIT APPLICANT – GET (load all data) =================
app.get("/edit/:id", (req, res) => {
  const id = req.params.id;

  const q = (sql, params) => new Promise((resolve, reject) => {
    dbconn.query(sql, params, (err, rows) => err ? reject(err) : resolve(rows));
  });

  Promise.all([
    q("SELECT * FROM basic_table WHERE basic_id = ?", [id]),
    q("SELECT * FROM education_details WHERE student_id = ?", [id]),
    q("SELECT * FROM work_experience WHERE basic_id = ?", [id]),
    q("SELECT * FROM student_languages WHERE basic_id = ?", [id]),
    q(`SELECT st.*, t.tech_name, st.level FROM student_technologies st
       JOIN technologies t ON st.tech_id = t.tech_id
       WHERE st.basic_id = ?`, [id]),
    q("SELECT * FROM reference_contacts WHERE basic_id = ?", [id]),
    q("SELECT * FROM preferences WHERE basic_id = ?", [id]),
  ])
  .then(([basicRows, education, workexp, languages, technologies, references, prefRows]) => {
    if (!basicRows.length) return res.send("Applicant not found");
    res.render("edit_form", {
      basic: basicRows[0],
      education,
      workexp,
      languages,
      technologies,
      references,
      preferences: prefRows[0] || {},
    });
  })
  .catch(err => { console.log(err); res.send("DB Error"); });
});

// ================= EDIT APPLICANT – POST (save changes) =================
app.post("/edit/:id", (req, res) => {
  const id = req.params.id;
  const {
    fname, lname, Designation, Address1, Address2, Email, city, state,
    gender, zipcode, relationshipstatus, phonenumber, db,
    nameofboard,  passingyear,  percentage1,
    nameofboard1, passingyear1, percentage2,
    coursename1,  University1,  passingyear2, percentage3,
    coursename2,  University2,  passingyear3, percentage4,
    company1, designation1, from1, to1,
    company2, designation2, from2, to2,
    company3, designation3, from3, to3,
    english, englishRead, englishWrite, englishSpeak,
    hindi,   hindiRead,   hindiWrite,   hindiSpeak,
    gujarati,gujaratiRead,gujaratiWrite,gujaratiSpeak,
    php, php_level, laravel, laravel_level, mysql, mysql_level,
    oracle, oracle_level, javascript, javascript_level,
    react, react_level, nodejs, nodejs_level,
    name1, contact1, relation1,
    name2, contact2, relation2,
    preferred_location, notice_period, department, expected_ctc,
  } = req.body;

  const q = (sql, params) => new Promise((resolve, reject) => {
    dbconn.query(sql, params, (err, result) => err ? reject(err) : resolve(result));
  });

  // 1. Update basic_table
  const updateBasic = q(
    `UPDATE basic_table SET first_name=?,last_name=?,designation=?,address1=?,address2=?,
     email=?,city=?,state1=?,gender=?,zipcode=?,rs=?,phoneno=?,dob=? WHERE basic_id=?`,
    [fname,lname,Designation,Address1,Address2,Email,city,state,gender,zipcode,
     relationshipstatus,phonenumber,db,id]
  );

  // 2. Update education_details (by student_id + type)
  const updateEdu = Promise.all([
    q(`UPDATE education_details SET board_or_university=?,passing_year=?,percentage=?,course_name=NULL
       WHERE student_id=? AND education_type_id=1`,[nameofboard,passingyear,percentage1,id]),
    q(`UPDATE education_details SET board_or_university=?,passing_year=?,percentage=?,course_name=NULL
       WHERE student_id=? AND education_type_id=2`,[nameofboard1,passingyear1,percentage2,id]),
    q(`UPDATE education_details SET course_name=?,board_or_university=?,passing_year=?,percentage=?
       WHERE student_id=? AND education_type_id=3`,[coursename1,University1,passingyear2,percentage3,id]),
    q(`UPDATE education_details SET course_name=?,board_or_university=?,passing_year=?,percentage=?
       WHERE student_id=? AND education_type_id=4`,[coursename2,University2,passingyear3,percentage4,id]),
  ]);

  // 3. Rebuild work_experience
  const newWork = [
    [id, company1, designation1, from1, to1],
    [id, company2, designation2, from2, to2],
    [id, company3, designation3, from3, to3],
  ].filter(v => v[1] && v[2]);

  const updateWork = q("DELETE FROM work_experience WHERE basic_id=?", [id])
    .then(() => newWork.length ? q("INSERT INTO work_experience (basic_id,company_name,designation,from_date,to_date) VALUES ?", [newWork]) : Promise.resolve());

  // 4. Rebuild student_languages
  const langValues = [];
  if (english)  langValues.push([id,1, englishRead?1:0,  englishWrite?1:0,  englishSpeak?1:0]);
  if (hindi)    langValues.push([id,2, hindiRead?1:0,    hindiWrite?1:0,    hindiSpeak?1:0]);
  if (gujarati) langValues.push([id,3, gujaratiRead?1:0, gujaratiWrite?1:0, gujaratiSpeak?1:0]);

  const updateLang = q("DELETE FROM student_languages WHERE basic_id=?", [id])
    .then(() => langValues.length ? q("INSERT INTO student_languages (basic_id,lang_id,can_read,can_write,can_speak) VALUES ?", [langValues]) : Promise.resolve());

  // 5. Rebuild student_technologies
  const techMap = {
    php: { name:'PHP', level: php_level },
    laravel: { name:'Laravel', level: laravel_level },
    mysql: { name:'MySQL', level: mysql_level },
    oracle: { name:'Oracle', level: oracle_level },
    javascript: { name:'JavaScript', level: javascript_level },
    react: { name:'React', level: react_level },
    nodejs: { name:'Node.js', level: nodejs_level },
  };
  const selectedTechs = Object.entries(techMap)
    .filter(([key]) => req.body[key])
    .map(([, val]) => val);

  const updateTech = q("DELETE FROM student_technologies WHERE basic_id=?", [id])
    .then(() => {
      if (!selectedTechs.length) return;
      const insertOneTech = (index) => {
        if (index >= selectedTechs.length) return Promise.resolve();
        const { name, level } = selectedTechs[index];
        return q("SELECT tech_id FROM technologies WHERE tech_name=?", [name])
          .then(rows => {
            if (rows.length) return q("INSERT INTO student_technologies (basic_id,tech_id,level) VALUES (?,?,?)", [id,rows[0].tech_id,level||'Beginner']);
            return q("INSERT INTO technologies (tech_name) VALUES (?)", [name])
              .then(r => q("INSERT INTO student_technologies (basic_id,tech_id,level) VALUES (?,?,?)", [id,r.insertId,level||'Beginner']));
          })
          .then(() => insertOneTech(index + 1));
      };
      return insertOneTech(0);
    });

  // 6. Rebuild reference_contacts
  const refValues = [
    [id, name1, contact1, relation1],
    [id, name2, contact2, relation2],
  ].filter(v => v[1]);

  const updateRef = q("DELETE FROM reference_contacts WHERE basic_id=?", [id])
    .then(() => refValues.length ? q("INSERT INTO reference_contacts (basic_id,name,contact_number,relation) VALUES ?", [refValues]) : Promise.resolve());

  // 7. Update preferences
  const updatePref = q(
    `INSERT INTO preferences (basic_id,preferred_location,notice_period,department,expected_ctc)
     VALUES (?,?,?,?,?)
     ON DUPLICATE KEY UPDATE
     preferred_location=VALUES(preferred_location), notice_period=VALUES(notice_period),
     department=VALUES(department), expected_ctc=VALUES(expected_ctc)`,
    [id, preferred_location, notice_period, department, expected_ctc]
  );

  Promise.all([updateBasic, updateEdu, updateWork, updateLang, updateTech, updateRef, updatePref])
    .then(() => res.redirect("/applicants"))
    .catch(err => { console.log(err); res.send("DB Error during update"); });
});

// Start server
app.listen(5000, () => {
  console.log(`http://localhost:5000`);
});
