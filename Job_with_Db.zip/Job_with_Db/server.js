const express = require("express");
const dbconn = require("./config/db");
const app = express();
const port = process.env.PORT || 3000;

app.set("view engine", "ejs");

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes

app.get("/", (req, res) => {
  // console.log(req.body)
  res.render("./basic_form");
});

app.post("/", (req, res) => {
  console.log(req.body);
  let {
    fname,
    lname,
    Designation,
    Address1,
    Address2,
    Email,
    city,
    state,
    gender,
    zipcode,
    relationshipstatus,
    phonenumber,
    db
  } = req.body;
  //const sql = "INSERT INTO basic_table (first_name,last_name,designation,adress1,adress2,email,city,state1,gender,rs,dob,phoneno,zipcode) values ?";
  //const sql = "INSERT INTO basic_table (first_name, last_name, designation, address1, address2,email,city, state1,gender,rs , dob, phoneno) VALUES ?";
  const sql = `INSERT INTO basic_table
    (first_name, last_name, designation, address1, address2, email, city, state1, gender,zipcode, rs, phoneno, dob)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)`;
//   const values = ;
   dbconn.query(sql,[
    fname,
    lname,
    Designation,
    Address1,
    Address2,
    Email,
    city,
    state,
    gender,
    zipcode,
    relationshipstatus,
    phonenumber,
    db
  ], (err,result) => {
    if(err){
         console.log(err)
        // res.send("error in db insert")
    }
     const studentId = result.insertId;
    //  console.log(studentId);

        console.log("success");
        res.redirect(`/education?student_id=${studentId}`);
  });
  });

app.get("/", (req, res) => {
  res.render("basic_form");
});

app.get("/education", (req, res) => {
         const studentId = req.query.student_id;
//  console.log(studentId)
  res.render("education_form",{studentId});
});

app.post("/education", (req, res) => {
  console.log(req.body);
  let {
    student_id,
        nameofboard,
        passingyear,
        percentage1,

        nameofboard1,
        passingyear1,
        percentage2,

        coursename,
        University,
        passingyear2,
        percentage3,

        passingyear3,
        percentage4
  } = req.body;

   const sql = `
    INSERT INTO education_details
    (student_id, education_type_id, course_name, board_or_university, passing_year, percentage)
    VALUES ?
    `;
  const values = [
        [student_id, 1, null, nameofboard, passingyear, percentage1],
        [student_id, 2, null, nameofboard1, passingyear1, percentage2],
        [student_id, 3, coursename, University, passingyear2, percentage3],
        [student_id, 4, coursename, University, passingyear3, percentage4]
    ];

    dbconn.query(sql, [values], (err, result) => {

        if (err) {
            console.log(err);
            return res.send("DB error");
        }

        const studentId = req.query.student_id;

        // res.redirect("/workexeprience");
         console.log("success");
        res.redirect(`/workexp?student_id=${student_id}`);

    });
});

app.get("/workexp", (req, res) => {
     const studentId = req.query.student_id;
  res.render("workexp_form",{studentId});
});

app.post("/workexp",(req,res)=>{
    const {
         studentId,
        company1,
        designation1,
        from1,
        to1,
        company2,
        designation2,
        from2,
        to2,
        company3,
        designation3,
        from3,
        to3
    } = req.body 
        const sql = "INSERT INTO work_experience (basic_id,company_name,designation,from_date,to_date) values ?"

    const values = [
        [basic_id, company1, designation1, from1, to1],
        [basic_id, company2, designation2, from2, to2],
        [basic_id, company3, designation3, from3, to3]
    ];

    dbconn.query(sql, [values], (err, result) => {
        if (err) {
            console.log(err)
            res.send("error")
        }
        console.log("success")
        res.redirect(`/preferances?student_id=${studentId}`, {studentId});
    })
   
})

app.get("/languageknown", (req, res) => {

});

app.get("/referances", (req, res) => {
  res.render("referances");
});

app.get("/preferances", (req, res) => {
  res.render("preferances");
});


// Start server
app.listen(8000, () => {
  console.log(`http://localhost:8000`);
});
