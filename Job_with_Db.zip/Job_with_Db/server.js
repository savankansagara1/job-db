const express = require("express");
const dbconn = require("./config/db");
const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));

// ================= BASIC =================
app.get("/", (req, res) => {
  res.render("basic_form");
});

app.post("/", (req, res) => {
  const {
    fname,
    lname,
    Designation,
    Address1,
    Address2,
    Email,
    city,
    state,
    gender,
    zipcode,
    relationshipstatus,
    phonenumber,
    db,
  } = req.body;

  const sql = `INSERT INTO basic_table
  (first_name,last_name,designation,address1,address2,email,city,state1,gender,zipcode,rs,phoneno,dob)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`;

  dbconn.query(
    sql,
    [
      fname,
      lname,
      Designation,
      Address1,
      Address2,
      Email,
      city,
      state,
      gender,
      zipcode,
      relationshipstatus,
      phonenumber,
      db,
    ],
    (err, result) => {
      if (err) return res.send("DB Error");
      res.redirect(`/education?student_id=${result.insertId}`);
    },
  );
});

// ================= EDUCATION =================
app.get("/education", (req, res) => {
  res.render("education_form", { studentId: req.query.student_id });
});

app.post("/education", (req, res) => {
  const {
    student_id,
    nameofboard,
    passingyear,
    percentage1,
    nameofboard1,
    passingyear1,
    percentage2,
    coursename1,
    University1,
    passingyear2,
    percentage3,
    coursename2,
    University2,
    passingyear3,
    percentage4,
  } = req.body;

  const sql = `INSERT INTO education_details (student_id, education_type_id, course_name, board_or_university, passing_year, percentage) VALUES ?`;

  const values = [
    [student_id, 1, null, nameofboard, passingyear, percentage1],
    [student_id, 2, null, nameofboard1, passingyear1, percentage2],
    [student_id, 3, coursename1, University1, passingyear2, percentage3],
    [student_id, 4, coursename2, University2, passingyear3, percentage4],
  ];

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/workexp?student_id=${student_id}`);
  });
});

// ================= WORK =================
app.get("/workexp", (req, res) => {
  res.render("workexp_form", { studentId: req.query.student_id });
});

app.post("/workexp", (req, res) => {
  const {
    studentId,
    company1,
    designation1,
    from1,
    to1,
    company2,
    designation2,
    from2,
    to2,
    company3,
    designation3,
    from3,
    to3,
  } = req.body;

  const sql = `INSERT INTO work_experience (basic_id, company_name, designation, from_date, to_date) VALUES ?`;

  const values = [
    [studentId, company1, designation1, from1, to1],
    [studentId, company2, designation2, from2, to2],
    [studentId, company3, designation3, from3, to3],
  ].filter((v) => v[1] && v[2]);

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/languageknown?student_id=${studentId}`);
  });
});

// ================= LANGUAGE =================
app.get("/languageknown", (req, res) => {
  res.render("languageKnown", { studentId: req.query.student_id });
});

app.post("/languageknown", (req, res) => {
  const {
    studentId,
    english,
    englishRead,
    englishWrite,
    englishSpeak,
    hindi,
    hindiRead,
    hindiWrite,
    hindiSpeak,
    gujarati,
    gujaratiRead,
    gujaratiWrite,
    gujaratiSpeak,
  } = req.body;

  const sql = `
    INSERT INTO student_languages
    (basic_id, lang_id, can_read, can_write, can_speak)
    VALUES ?
  `;

  let values = [];

  // English → lang_id = 1
  if (english) {
    values.push([
      studentId,
      1,
      englishRead ? 1 : 0,
      englishWrite ? 1 : 0,
      englishSpeak ? 1 : 0,
    ]);
  }

  // Hindi → lang_id = 2
  if (hindi) {
    values.push([
      studentId,
      2,
      hindiRead ? 1 : 0,
      hindiWrite ? 1 : 0,
      hindiSpeak ? 1 : 0,
    ]);
  }

  // Gujarati → lang_id = 3
  if (gujarati) {
    values.push([
      studentId,
      3,
      gujaratiRead ? 1 : 0,
      gujaratiWrite ? 1 : 0,
      gujaratiSpeak ? 1 : 0,
    ]);
  }

  // If nothing selected → skip insert
  if (values.length === 0) {
    return res.redirect(`/referances?student_id=${studentId}`);
  }

  dbconn.query(sql, [values], (err, result) => {
    if (err) {
      console.log(err);
      return res.send("DB Error");
    }

    console.log("Language inserted");

    res.redirect(`/referances?student_id=${studentId}`);
  });
});

app.get("/referances", (req, res) => {
  const studentId = req.query.student_id;

  res.render("referances", { studentId });
});

app.post("/referances", (req, res) => {
  const { studentId, name1, contact1, relation1, relation2, name2, contact2 } =
    req.body;
  console.log(req.body);

  const sql = `INSERT INTO reference_contacts (basic_id,name,contact_number,relation) values ?`;
  const values = [
    [studentId, name1, contact1, relation1],
    [studentId, name2, contact2, relation2],
  ];

  dbconn.query(sql, [values], (err) => {
    if (err) return res.send("DB Error");
    res.redirect(`/preferances?student_id=${studentId}`);
  });
});

app.get("/preferances", (req, res) => {
  res.render("preferances", { studentId: req.query.student_id });
});

app.post("/preferances", (req, res) => {
  const {
    studentId,
    preferred_location,
    notice_period,
    department,
    expected_ctc,
  } = req.body;

const sql = `INSERT INTO preferences 
(basic_id, preferred_location, notice_period, department, expected_ctc) 
VALUES (?, ?, ?, ?, ?)`;

  const values = [
    studentId,
    preferred_location,
    notice_period,
    department,
    expected_ctc
  ];

  dbconn.query(sql, [values], (err) => {
    if (err) {
      return res.send("dbErr");
    } else {
      console.log("success");
      res.send(`<script>
      alert("Your form has been submitted successfully!");
      window.location.href = "/"; 
    </script>`);
    }
  });
});
// Start server
app.listen(5000, () => {
  console.log(`http://localhost:5000`);
});
