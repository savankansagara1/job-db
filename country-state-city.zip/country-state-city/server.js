const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const dbconn = require("./config/db")

const app = express();
app.use(cors());
app.use(express.json());


// ROUTES

// 1. Get Countries
app.get("/countries", (req, res) => {
  dbconn.query("SELECT * FROM countries", (err, result) => {
    if (err) return res.json(err);
    res.json(result);
  });
});

// 2. Get States by Country
app.get("/states/:countryId", (req, res) => {
  const { countryId } = req.params;

  dbconn.query(
    "SELECT * FROM states WHERE country_id = ?",
    [countryId],
    (err, result) => {
      if (err) return res.json(err);
      res.json(result);
    }
  );
});

// 3. Get Cities by State
app.get("/cities/:stateId", (req, res) => {
  const { stateId } = req.params;

  dbconn.query(
    "SELECT * FROM cities WHERE state_id = ?",
    [stateId],
    (err, result) => {
      if (err) return res.json(err);
      res.json(result);
    }
  );
});

// SERVER START
app.listen(3000, () => {
  console.log("Server running on port 3000");
});